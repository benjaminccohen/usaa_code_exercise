package com.beenjammiin.usaa.codesample;

import org.springframework.web.reactive.function.client.WebClient;

import java.util.Objects;

public class Provider_CarData implements VehiclePriceProvider {
    private static final String uriTemplate = "/cardata/vehicles/prices?year=%s&make=%s&model=%s&condition=%s";
    private VehicleSpecification spec = null;
    private VehiclePrices prices = null;
    private WebClient client =  WebClient.create("http://localhost:8080");

    public Provider_CarData()
    {
    }

    @Override
    public void setSpecification(VehicleSpecification spec)
    {
        this.spec = spec;
    }

    @Override
    public VehiclePrices getPrices() {
        VehiclePrices result = client.get().uri(Objects.requireNonNull(formatURI())).retrieve().bodyToMono(VehiclePrices.class).block();
        return result;
    }

    private String formatURI()
    {
        return String.format(uriTemplate, spec.getYear(), spec.getMake(), spec.getModel(), spec.getCondition().toString());
    }
}


