package com.beenjammiin.usaa.codesample;

public interface VehicleFeatureProvider {
    public VehicleFeatures getFeatures();
    void setSpecification(VehicleSpecification spec);
}
