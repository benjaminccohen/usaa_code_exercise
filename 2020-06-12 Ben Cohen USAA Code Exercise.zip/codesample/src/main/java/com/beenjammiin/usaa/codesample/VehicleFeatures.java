package com.beenjammiin.usaa.codesample;

public class VehicleFeatures {
    private String features;

    public VehicleFeatures(String features) {
        this.features = features;
    }

    public VehicleFeatures()
    {
    }

    public String getFeatures() {
        return features;
    }
    public void setFeatures(String features) {
        this.features = features;
    }
}
