package com.beenjammiin.usaa.codesample;

public interface VehiclePriceProvider {
    public VehiclePrices getPrices();
    public void setSpecification(VehicleSpecification spec);
}
