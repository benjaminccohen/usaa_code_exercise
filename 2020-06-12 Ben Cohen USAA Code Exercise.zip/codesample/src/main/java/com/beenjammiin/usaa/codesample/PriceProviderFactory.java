package com.beenjammiin.usaa.codesample;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class PriceProviderFactory {
    private static final List<String> priceProviders = Arrays.asList("com.beenjammiin.usaa.codesample.Provider_CarData","com.beenjammiin.usaa.codesample.Provider_FairPricedVehicles","com.beenjammiin.usaa.codesample.Provider_AutoHistory");

    public static List<VehiclePriceProvider> getPriceProviders(VehicleSpecification spec)
    {
        List<VehiclePriceProvider> result = priceProviders.stream().map(provider -> getProviderInstanceByName(provider, spec)).filter(Objects::nonNull).collect(Collectors.toList());
        return result;
    }

    private static VehiclePriceProvider getProviderInstanceByName(String className, VehicleSpecification spec)
    {
        try {
            VehiclePriceProvider result =  (VehiclePriceProvider)(Class.forName(className).newInstance());
            result.setSpecification(spec);
            return result;
        }
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException c) {
            return null;
        }

    }
}
