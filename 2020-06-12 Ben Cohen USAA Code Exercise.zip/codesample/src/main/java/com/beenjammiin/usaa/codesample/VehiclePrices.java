package com.beenjammiin.usaa.codesample;

public class VehiclePrices {
    private int low;
    private int high;

    public VehiclePrices(int low, int high) {
        this.low = low;
        this.high = high;
    }

    public VehiclePrices() {
    }

    public int getLow() {
        return low;
    }
    public int getHigh() {
        return high;
    }
    public void setLow(int low) {
        this.low = low;
    }
    public void setHigh(int high) {
        this.high = high;
    }
}
