package com.beenjammiin.usaa.codesample;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@RestController
public class VehicleDataController {
    @GetMapping("/vehicles/prices")
    public List<VehiclePrices> prices(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition) {
        VehicleSpecification spec = null;
        try {
            spec = VehicleSpecification.initialize(year, make, model, condition);
        } catch (VehicleSpecification.MissingOrInvalidInputException _e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }

        List<VehiclePriceProvider> providers = PriceProviderFactory.getPriceProviders((spec));
        List<VehiclePrices> result = providers.stream().map(VehiclePriceProvider::getPrices).collect(Collectors.toList());
        return result;
    }

    @GetMapping("/vehicles/features")
    public List<VehicleFeatures> features(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        VehicleSpecification spec = null;
        try {
            spec = VehicleSpecification.initialize(year, make, model, condition);
        }
        catch (VehicleSpecification.MissingOrInvalidInputException _e)
        {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST);
        }

        List<VehicleFeatureProvider> providers = FeatureProviderFactory.getFeatureProviders((spec));
        List<VehicleFeatures> result = providers.stream().map(VehicleFeatureProvider::getFeatures).collect(Collectors.toList());
        return result;
    }
}
