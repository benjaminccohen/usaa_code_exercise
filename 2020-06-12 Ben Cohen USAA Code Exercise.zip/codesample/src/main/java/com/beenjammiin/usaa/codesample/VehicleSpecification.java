package com.beenjammiin.usaa.codesample;

public class VehicleSpecification {
    public static class MissingOrInvalidInputException extends Exception {}
    public enum VehicleCondition {NEW, USED}

    private final int year;
    private final String make;
    private final String model;
    private final VehicleCondition condition;

    public VehicleSpecification(int year, String make, String model, VehicleCondition condition) {
        this.year = year;
        this.make = make;
        this.model = model;
        this.condition = condition;
    }

    public static VehicleSpecification initialize(String year, String make, String model, String condition) throws MissingOrInvalidInputException {

        if (    null == year || year.isEmpty()
                ||  null == make || make.isEmpty()
                ||  null == model || model.isEmpty()
                ||  null == condition || condition.isEmpty())
        {
            throw new MissingOrInvalidInputException();
        }

        boolean invalidData = false;
        int yearV = 0;
        VehicleCondition conditionV = VehicleCondition.NEW;

        try { yearV = Integer.parseInt(year); } catch(Exception _e) { invalidData = true; }
        try { conditionV = VehicleCondition.valueOf(condition); } catch(Exception _e) { invalidData = true; }
        // could add more checks for year, make and model for sanity, if desired
        if (invalidData)
        {
            // return 400 for invalid parameters, could still do 404, opinions vary
            throw new MissingOrInvalidInputException();
        }

        return new VehicleSpecification(yearV, make, model, conditionV);
    }

    public int getYear() {
        return year;
    }
    public String getMake() {
        return make;
    }
    public String getModel() {
        return model;
    }
    public VehicleCondition getCondition() {
        return condition;
    }
}
