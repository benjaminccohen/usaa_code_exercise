package com.beenjammiin.usaa.codesample;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class FeatureProviderFactory {
    private static final List<String> featureProviders = Arrays.asList("com.beenjammiin.usaa.codesample.Provider_BuyGoodCars","com.beenjammiin.usaa.codesample.Provider_PriceCompare");

    public static List<VehicleFeatureProvider> getFeatureProviders(VehicleSpecification spec)
    {
        List<VehicleFeatureProvider> result = featureProviders.stream().map(provider -> getProviderInstanceByName(provider, spec)).filter(Objects::nonNull).collect(Collectors.toList());
        return result;
    }

    private static VehicleFeatureProvider getProviderInstanceByName(String className, VehicleSpecification spec)
    {
        try {
            VehicleFeatureProvider result =  (VehicleFeatureProvider)(Class.forName(className).newInstance());
            result.setSpecification(spec);
            return result;
        }
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException c) {
            return null;
        }

    }
}
