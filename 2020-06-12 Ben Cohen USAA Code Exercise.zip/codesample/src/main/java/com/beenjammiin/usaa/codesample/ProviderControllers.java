package com.beenjammiin.usaa.codesample;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class ProviderControllers {
    @GetMapping("/cardata/vehicles/prices")
    public VehiclePrices cardata_prices(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        return new VehiclePrices(5,10);
    }

    @GetMapping("/fairpricedvehicles/vehicles/prices")
    public VehiclePrices fairpricedvehicles_prices(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        return new VehiclePrices(1,7);
    }

    @GetMapping("/autohistory/vehicles/prices")
    public VehiclePrices autohistory_prices(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        return new VehiclePrices(2,2);
    }

    @GetMapping("/buygoodcars/vehicles/features")
    public VehicleFeatures buygoodcars_features(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        return new VehicleFeatures("Power Windows, Power Locks, GPS");
    }

    @GetMapping("/pricecompare/vehicles/features")
    public VehicleFeatures pricecompare_features(
            @RequestParam(value = "year") String year,
            @RequestParam(value = "make") String make,
            @RequestParam(value = "model") String model,
            @RequestParam(value = "condition") String condition)
    {
        return new VehicleFeatures("Power Windows, Manual Transmission, Leather, 3.35:1 Differential");
    }
}
