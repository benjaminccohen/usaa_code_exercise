package com.beenjammiin.usaa.codesample;

import org.springframework.web.reactive.function.client.WebClient;

import java.util.Objects;

public class Provider_PriceCompare implements VehicleFeatureProvider {
    private static final String uriTemplate = "/pricecompare/vehicles/features?year=%s&make=%s&model=%s&condition=%s";
    private VehicleSpecification spec = null;
    private WebClient client =  WebClient.create("http://localhost:8080");

    public Provider_PriceCompare()
    {
    }

    @Override
    public void setSpecification(VehicleSpecification spec)
    {
        this.spec = spec;
    }

    @Override
    public VehicleFeatures getFeatures() {
        VehicleFeatures result = client.get().uri(Objects.requireNonNull(formatURI())).retrieve().bodyToMono(VehicleFeatures.class).block();
        return result;
    }

    private String formatURI()
    {
        return String.format(uriTemplate, spec.getYear(), spec.getMake(), spec.getModel(), spec.getCondition().toString());
    }
}


