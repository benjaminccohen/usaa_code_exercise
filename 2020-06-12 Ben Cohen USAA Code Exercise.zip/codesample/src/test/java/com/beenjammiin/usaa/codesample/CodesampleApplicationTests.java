package com.beenjammiin.usaa.codesample;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class CodesampleApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@Test
	public void invalidPathReturns404() throws Exception {
		this.mockMvc.perform(get("/")).andDo(print()).andExpect(status().isNotFound());
	}

	@Test
	public void prices_noParametersReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_noYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_noMakeParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year","1968").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_noModelParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year","1968").param("make", "Chevrolet").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_noConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year","1968").param("make", "Chevrolet").param("model","Camaro")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_emptyYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_emptyMakeParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_emptyModelParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "Chevrolet").param("model","").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_emptyConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_malformedYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "abcd").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_malformedConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "SALVAGE")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void prices_USEDConditionParameterParses() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isOk());//.andExpect(jsonPath("$.condition").value("USED"));
	}

	@Test
	public void prices_NEWConditionParameterParses() throws Exception {
		this.mockMvc.perform(get("/vehicles/prices").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "NEW")).andDo(print()).andExpect(status().isOk());//.andExpect(jsonPath("$.condition").value("NEW"));
	}

	@Test
	public void features_noParametersReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_noYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_noMakeParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year","1968").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_noModelParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year","1968").param("make", "Chevrolet").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_noConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year","1968").param("make", "Chevrolet").param("model","Camaro")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_emptyYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_emptyMakeParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_emptyModelParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "Chevrolet").param("model","").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_emptyConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_malformedYearParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "abcd").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_malformedConditionParameterReturns404() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "SALVAGE")).andDo(print()).andExpect(status().isBadRequest());
	}

	@Test
	public void features_USEDConditionParameterParses() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "USED")).andDo(print()).andExpect(status().isOk());//.andExpect(jsonPath("$.condition").value("USED"));
	}

	@Test
	public void features_NEWConditionParameterParses() throws Exception {
		this.mockMvc.perform(get("/vehicles/features").param("year", "1968").param("make", "Chevrolet").param("model","Camaro").param("condition", "NEW")).andDo(print()).andExpect(status().isOk());//.andExpect(jsonPath("$.condition").value("NEW"));
	}

}
