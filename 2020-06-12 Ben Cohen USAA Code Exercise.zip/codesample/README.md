# Coding Exercise for USAA Senior Software Engineer
# Author: Benjamin Cohen
# Date: 2020-06-12

This was developed using IntelliJ Ultimate 2020.1, using Maven for build management.

Architecture:
This is a Spring Boot Rest application that exposes two endpoints: /vehicles/prices and /vehicles/features
Both endpoints expect a vehicle year, make, model and condition as parameters.

ex:
http://localhost:8080/vehicles/features?year=1968&make=fiat&model=124&condition=USED
http://localhost:8080/vehicles/prices?year=1968&make=fiat&model=124&condition=USED

Other than being validated, the inputs are not used at this time.  Missing or malformed inputs return a 404.

The application retrieves data from multiple providers and returns the in a single response as a list, with one element for each provider.
Price is represented as two integers, low an haigh, to denote a range.
Features are simply a comma separated list.*

*The original representation was HashSet<String>, but while that was working for each provider I was having an issue marshalling the List<HashSet<String>> to JSON.

The approach uses a provider interface and a provider factory to fetch a list of provider instances.
This is used for both features and prices, which are generally symetric at this time, however I chose not to abstract the underlying functionality since I believe these could be quite different in a real-world implementation.
The list of provider classes is currently hardcoded in the factory classes; this should be moved into an injectable resource, or better yet, a plugin architecture that searches a specific classpath for classes implementing the appropriate interfaces.

The provider instances are also highly symetric, although this would not be expected in a real world; each would provide an adapter to a specific API which maps to the generic functionality.

Although the API calls to each provider are made using a reactive WebClient they are still being processed sequentially.  This should be refactored for parallel execution.

Individual providers can be accessed at the following endpoints:
/buygoodcars/vehicles/features
/pricecompare/vehicles/features
/cardata/vehicles/prices
/fairpricedvehicles/vehicles/prices
/autohistory/vehicles/prices

Unit tests cover the basic validation, however the positive cases are failling for me at this time.
I can access the endpoints form the browser, but when running in test mode an exception is generated.

Other things to do not mentioned above:
1) More comments
2) More docs
3) UML diagrams
4) More robust error handling and reporting

